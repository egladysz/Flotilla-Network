#pragma once
using glID = unsigned int;
using glIndex = unsigned int;