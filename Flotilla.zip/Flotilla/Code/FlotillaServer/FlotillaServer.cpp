#include "FlotillaServer.h"

FlotillaServer::FlotillaServer(unsigned short port)
	:Server(port)
{

}
